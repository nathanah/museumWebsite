Elisabeth Henkens ID: 914001438
Nathan Hoffman ID: 913987236

Our HTML expects images to be in directory ../assets/img.png
Laptop: > 810px
Tablet: 810px > width > 550px
Mobile: < 550px
